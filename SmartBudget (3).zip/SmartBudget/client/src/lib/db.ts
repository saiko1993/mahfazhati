import { openDB, DBSchema, IDBPDatabase } from 'idb';
import { Wallet, Transaction, Notification } from '@shared/schema';

// Define database schema
interface MahfazhatiDB extends DBSchema {
  wallets: {
    key: string;
    value: Wallet;
    indexes: {
      'by-phone': string;
      'by-type': string;
      'by-balance': number;
      'by-date': string;
    };
  };
  transactions: {
    key: string;
    value: Transaction;
    indexes: {
      'by-wallet': string;
      'by-type': string;
      'by-date': string;
      'by-amount': number;
    };
  };
  notifications: {
    key: string;
    value: Notification;
    indexes: {
      'by-type': string;
      'by-date': string;
      'by-read': boolean;
    };
  };
  settings: {
    key: string;
    value: any;
  };
}

// Database version
const DB_VERSION = 1;
const DB_NAME = 'mahfazhati-db';

// Database instance
let db: IDBPDatabase<MahfazhatiDB> | null = null;

// Initialize and get database
export async function getDB(): Promise<IDBPDatabase<MahfazhatiDB>> {
  if (db) return db;

  db = await openDB<MahfazhatiDB>(DB_NAME, DB_VERSION, {
    upgrade(db) {
      // Create wallets store
      if (!db.objectStoreNames.contains('wallets')) {
        const walletStore = db.createObjectStore('wallets', { keyPath: 'id' });
        walletStore.createIndex('by-phone', 'phoneNumber');
        walletStore.createIndex('by-type', 'type');
        walletStore.createIndex('by-balance', 'balance');
        walletStore.createIndex('by-date', 'lastUpdated');
      }

      // Create transactions store
      if (!db.objectStoreNames.contains('transactions')) {
        const transactionStore = db.createObjectStore('transactions', { keyPath: 'id' });
        transactionStore.createIndex('by-wallet', 'walletId');
        transactionStore.createIndex('by-type', 'type');
        transactionStore.createIndex('by-date', 'date');
        transactionStore.createIndex('by-amount', 'amount');
      }

      // Create notifications store
      if (!db.objectStoreNames.contains('notifications')) {
        const notificationStore = db.createObjectStore('notifications', { keyPath: 'id' });
        notificationStore.createIndex('by-type', 'type');
        notificationStore.createIndex('by-date', 'date');
        notificationStore.createIndex('by-read', 'isRead');
      }

      // Create settings store
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'id' });
      }
    },
  });

  return db;
}

// Close the database connection
export function closeDB() {
  if (db) {
    db.close();
    db = null;
  }
}

// Generate UUID for new entities
export function generateId(): string {
  return crypto.randomUUID();
}

// Check if IndexedDB is available
export function isIndexedDBAvailable(): boolean {
  return 'indexedDB' in window;
}
