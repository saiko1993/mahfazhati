import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { Wallet, Transaction, Notification } from '@shared/schema';
import {
  getAllWallets,
  getWalletById,
  addWallet,
  updateWallet,
  updateWalletBalance,
  deleteWallet,
  getAllTransactions,
  getTransactionsByWalletId,
  addTransaction,
  updateTransaction,
  deleteTransaction,
  getAllNotifications,
  addNotification,
  markNotificationAsRead,
  deleteNotification,
  getSetting,
  setSetting,
  exportAllData,
  importAllData,
  resetMonthlyLimits,
  shouldResetMonthlyLimits,
  updateLastResetDate
} from './indexedDB';
import { getCurrentDate } from './utils';

type SortOption = 'date' | 'name' | 'balance-asc' | 'balance-desc' | 'remaining-limit';
type FilterOption = 'all' | 'vodafone-cash' | 'etisalat-cash' | 'orange-cash' | 'we-cash';

interface State {
  wallets: Wallet[];
  transactions: Transaction[];
  notifications: Notification[];
  isOffline: boolean;
  isLoading: boolean;
  error: string | null;
  sortOption: SortOption;
  filterOption: FilterOption;
  autoBackupEnabled: boolean;
  autoBackupFrequency: 'daily' | 'weekly' | 'monthly';
  lastBackupDate: string | null;
  currentNotification: Notification | null;
  
  // Methods
  initializeStore: () => Promise<void>;
  fetchWallets: () => Promise<void>;
  fetchTransactions: () => Promise<void>;
  fetchNotifications: () => Promise<void>;
  
  // Wallet operations
  addWallet: (wallet: Omit<Wallet, 'id' | 'lastUpdated'>) => Promise<Wallet>;
  updateWallet: (wallet: Wallet) => Promise<Wallet>;
  updateWalletBalance: (id: string, newBalance: number, difference?: number) => Promise<Wallet>;
  deleteWallet: (id: string) => Promise<void>;
  
  // Transaction operations
  addTransaction: (transaction: Omit<Transaction, 'id' | 'date'>) => Promise<Transaction>;
  deleteTransaction: (id: string) => Promise<void>;
  
  // Notification operations
  addNotification: (notification: Omit<Notification, 'id' | 'date' | 'isRead'>) => Promise<Notification>;
  markNotificationAsRead: (id: string) => Promise<void>;
  clearNotification: () => void;
  
  // UI state operations
  setSortOption: (option: SortOption) => void;
  setFilterOption: (option: FilterOption) => void;
  setIsOffline: (offline: boolean) => void;
  
  // Monthly limit operations
  checkAndResetMonthlyLimits: () => Promise<boolean>;
  resetAllMonthlyLimits: () => Promise<number>;
  
  // Backup and restore
  setAutoBackup: (enabled: boolean) => Promise<void>;
  setAutoBackupFrequency: (frequency: 'daily' | 'weekly' | 'monthly') => Promise<void>;
  exportData: () => Promise<{
    wallets: Wallet[],
    transactions: Transaction[],
    notifications: Notification[],
    settings: Record<string, any>
  }>;
  importData: (data: any) => Promise<void>;
}

export const useStore = create<State>()(
  persist(
    (set, get) => ({
      wallets: [],
      transactions: [],
      notifications: [],
      isOffline: !navigator.onLine,
      isLoading: false,
      error: null,
      sortOption: 'date',
      filterOption: 'all',
      autoBackupEnabled: true,
      autoBackupFrequency: 'weekly',
      lastBackupDate: null,
      currentNotification: null,
      
      // Initialize the store and load initial data
      initializeStore: async () => {
        set({ isLoading: true, error: null });
        try {
          // Get settings first
          const autoBackupEnabled = await getSetting('autoBackupEnabled');
          const autoBackupFrequency = await getSetting('autoBackupFrequency');
          const lastBackupDate = await getSetting('lastBackupDate');
          
          // Set settings if they exist
          if (autoBackupEnabled) {
            set({ autoBackupEnabled: autoBackupEnabled.value });
          }
          
          if (autoBackupFrequency) {
            set({ autoBackupFrequency: autoBackupFrequency.value });
          }
          
          if (lastBackupDate) {
            set({ lastBackupDate: lastBackupDate.value });
          }
          
          // Then load data
          await get().fetchWallets();
          await get().fetchTransactions();
          await get().fetchNotifications();
          
          // التحقق من الحدود الشهرية وإعادة ضبطها إذا لزم الأمر
          const wasReset = await get().checkAndResetMonthlyLimits();
          if (wasReset) {
            console.log('تم إعادة ضبط الحدود الشهرية تلقائيًا عند بدء التطبيق');
          }
          
          set({ isLoading: false });
        } catch (error) {
          console.error('Failed to initialize store:', error);
          set({ isLoading: false, error: 'Failed to initialize the application. Please try again.' });
        }
      },
      
      // Fetch all wallets
      fetchWallets: async () => {
        try {
          const wallets = await getAllWallets();
          set({ wallets });
        } catch (error) {
          console.error('Error fetching wallets:', error);
          set({ error: 'Failed to fetch wallets' });
        }
      },
      
      // Fetch all transactions
      fetchTransactions: async () => {
        try {
          const transactions = await getAllTransactions();
          set({ transactions });
        } catch (error) {
          console.error('Error fetching transactions:', error);
          set({ error: 'Failed to fetch transactions' });
        }
      },
      
      // Fetch all notifications
      fetchNotifications: async () => {
        try {
          const notifications = await getAllNotifications();
          set({ notifications });
        } catch (error) {
          console.error('Error fetching notifications:', error);
          set({ error: 'Failed to fetch notifications' });
        }
      },
      
      // Add a new wallet
      addWallet: async (wallet) => {
        set({ isLoading: true, error: null });
        try {
          const newWallet = await addWallet(wallet);
          await get().fetchWallets(); // Refresh the list
          
          // Create a success notification
          await get().addNotification({
            title: 'تم إضافة المحفظة',
            message: `تم إضافة محفظة ${wallet.name} بنجاح`,
            type: 'success'
          });
          
          set({ isLoading: false });
          return newWallet;
        } catch (error) {
          console.error('Error adding wallet:', error);
          set({ 
            isLoading: false, 
            error: error instanceof Error ? error.message : 'Failed to add wallet' 
          });
          throw error;
        }
      },
      
      // Update a wallet
      updateWallet: async (wallet) => {
        set({ isLoading: true, error: null });
        try {
          const updatedWallet = await updateWallet(wallet);
          await get().fetchWallets(); // Refresh the list
          
          // Create a success notification
          await get().addNotification({
            title: 'تم تحديث المحفظة',
            message: `تم تحديث محفظة ${wallet.name} بنجاح`,
            type: 'success'
          });
          
          set({ isLoading: false });
          return updatedWallet;
        } catch (error) {
          console.error('Error updating wallet:', error);
          set({ 
            isLoading: false, 
            error: error instanceof Error ? error.message : 'Failed to update wallet' 
          });
          throw error;
        }
      },
      
      // Update wallet balance
      updateWalletBalance: async (id, newBalance, difference) => {
        set({ isLoading: true, error: null });
        try {
          // Get the wallet before updating
          const wallet = get().wallets.find(w => w.id === id);
          if (!wallet) {
            throw new Error("Wallet not found");
          }
          
          // Update the wallet balance
          const updatedWallet = await updateWalletBalance(id, newBalance, difference);
          await get().fetchWallets(); // Refresh the list
          
          // Create a notification about the balance update
          let notificationMessage = `تم تحديث رصيد محفظة ${wallet.name} إلى ${newBalance} جنيه`;
          let notificationType: 'success' | 'warning' | 'error' | 'info' = 'info';
          
          // إذا تم خصم من الحد المتبقي، نضيف تنبيه إضافي
          if (difference !== undefined && difference < 0) {
            notificationMessage += ` وخصم ${Math.abs(difference)} جنيه من الحد الشهري`;
            notificationType = 'warning';
          }
          
          await get().addNotification({
            title: 'تم تحديث الرصيد',
            message: notificationMessage,
            type: notificationType
          });
          
          set({ isLoading: false });
          return updatedWallet;
        } catch (error) {
          console.error('Error updating wallet balance:', error);
          set({ 
            isLoading: false, 
            error: error instanceof Error ? error.message : 'Failed to update wallet balance' 
          });
          throw error;
        }
      },
      
      // Delete a wallet
      deleteWallet: async (id) => {
        set({ isLoading: true, error: null });
        try {
          // Get the wallet name before deleting
          const wallet = get().wallets.find(w => w.id === id);
          
          await deleteWallet(id);
          await get().fetchWallets(); // Refresh the list
          await get().fetchTransactions(); // Also refresh transactions
          
          // Create a notification
          if (wallet) {
            await get().addNotification({
              title: 'تم حذف المحفظة',
              message: `تم حذف محفظة ${wallet.name} بنجاح`,
              type: 'info'
            });
          }
          
          set({ isLoading: false });
        } catch (error) {
          console.error('Error deleting wallet:', error);
          set({ 
            isLoading: false, 
            error: error instanceof Error ? error.message : 'Failed to delete wallet' 
          });
          throw error;
        }
      },
      
      // Add a new transaction
      addTransaction: async (transaction) => {
        set({ isLoading: true, error: null });
        try {
          const newTransaction = await addTransaction(transaction);
          
          // Refresh data
          await get().fetchTransactions();
          await get().fetchWallets();
          
          // Get wallet name
          const wallet = get().wallets.find(w => w.id === transaction.walletId);
          
          // Create a notification
          if (wallet) {
            let message = '';
            if (transaction.type === 'deposit') {
              message = `تم إضافة إيداع بقيمة ${transaction.amount} جنيه إلى محفظة ${wallet.name}`;
            } else if (transaction.type === 'withdrawal') {
              message = `تم إضافة سحب بقيمة ${transaction.amount} جنيه من محفظة ${wallet.name}`;
            } else {
              message = `تم إضافة تحويل بقيمة ${transaction.amount} جنيه ${transaction.amount > 0 ? 'إلى' : 'من'} محفظة ${wallet.name}`;
            }
            
            await get().addNotification({
              title: 'تمت إضافة المعاملة',
              message,
              type: 'success'
            });
          }
          
          set({ isLoading: false });
          return newTransaction;
        } catch (error) {
          console.error('Error adding transaction:', error);
          set({ 
            isLoading: false, 
            error: error instanceof Error ? error.message : 'Failed to add transaction' 
          });
          throw error;
        }
      },
      
      // Delete a transaction
      deleteTransaction: async (id) => {
        set({ isLoading: true, error: null });
        try {
          await deleteTransaction(id);
          
          // Refresh data
          await get().fetchTransactions();
          await get().fetchWallets();
          
          set({ isLoading: false });
        } catch (error) {
          console.error('Error deleting transaction:', error);
          set({ 
            isLoading: false, 
            error: error instanceof Error ? error.message : 'Failed to delete transaction' 
          });
          throw error;
        }
      },
      
      // Add a notification
      addNotification: async (notification) => {
        try {
          const newNotification = await addNotification(notification);
          await get().fetchNotifications();
          
          // Set as current notification to show in banner
          set({ currentNotification: newNotification });
          
          return newNotification;
        } catch (error) {
          console.error('Error adding notification:', error);
          throw error;
        }
      },
      
      // Mark notification as read
      markNotificationAsRead: async (id) => {
        try {
          await markNotificationAsRead(id);
          await get().fetchNotifications();
          
          // If it's the current notification, clear it
          const currentNotification = get().currentNotification;
          if (currentNotification && currentNotification.id === id) {
            set({ currentNotification: null });
          }
        } catch (error) {
          console.error('Error marking notification as read:', error);
          throw error;
        }
      },
      
      // Clear current notification
      clearNotification: () => {
        set({ currentNotification: null });
      },
      
      // Set sort option
      setSortOption: (option) => {
        set({ sortOption: option });
      },
      
      // Set filter option
      setFilterOption: (option) => {
        set({ filterOption: option });
      },
      
      // Set offline status
      setIsOffline: (offline) => {
        set({ isOffline: offline });
      },
      
      // التحقق مما إذا كان يجب إعادة ضبط الحدود الشهرية وتنفيذ ذلك إذا لزم الأمر
      checkAndResetMonthlyLimits: async () => {
        try {
          const shouldReset = await shouldResetMonthlyLimits();
          
          if (shouldReset) {
            const updatedCount = await resetMonthlyLimits();
            // تحديث تاريخ آخر إعادة ضبط
            await updateLastResetDate();
            
            // تحديث الواجهة بعد إعادة الضبط
            await get().fetchWallets();
            
            return true; // تم إعادة الضبط
          }
          
          return false; // لم يكن هناك حاجة لإعادة الضبط
        } catch (error) {
          console.error('خطأ أثناء التحقق من إعادة ضبط الحدود الشهرية:', error);
          return false;
        }
      },
      
      // إعادة ضبط الحد المتبقي لجميع المحافظ يدويًا
      resetAllMonthlyLimits: async () => {
        set({ isLoading: true, error: null });
        try {
          const updatedCount = await resetMonthlyLimits();
          // تحديث تاريخ آخر إعادة ضبط
          await updateLastResetDate();
          
          // تحديث الواجهة بعد إعادة الضبط
          await get().fetchWallets();
          
          set({ isLoading: false });
          return updatedCount;
        } catch (error) {
          console.error('خطأ أثناء إعادة ضبط الحدود الشهرية:', error);
          set({ 
            isLoading: false, 
            error: error instanceof Error ? error.message : 'فشل في إعادة ضبط الحدود الشهرية' 
          });
          return 0;
        }
      },
      
      // Set auto backup
      setAutoBackup: async (enabled) => {
        set({ autoBackupEnabled: enabled });
        await setSetting('autoBackupEnabled', enabled);
      },
      
      // Set auto backup frequency
      setAutoBackupFrequency: async (frequency) => {
        set({ autoBackupFrequency: frequency });
        await setSetting('autoBackupFrequency', frequency);
      },
      
      // Export data
      exportData: async () => {
        set({ isLoading: true, error: null });
        try {
          const data = await exportAllData();
          
          // Update last backup date
          const now = getCurrentDate();
          set({ lastBackupDate: now });
          await setSetting('lastBackupDate', now);
          
          set({ isLoading: false });
          return data;
        } catch (error) {
          console.error('Error exporting data:', error);
          set({ 
            isLoading: false, 
            error: error instanceof Error ? error.message : 'Failed to export data' 
          });
          throw error;
        }
      },
      
      // Import data
      importData: async (data) => {
        set({ isLoading: true, error: null });
        try {
          await importAllData(data);
          
          // Refresh data
          await get().fetchWallets();
          await get().fetchTransactions();
          await get().fetchNotifications();
          
          // Create a notification
          await addNotification({
            title: 'تم استعادة البيانات',
            message: 'تم استعادة البيانات بنجاح',
            type: 'success'
          });
          
          set({ isLoading: false });
        } catch (error) {
          console.error('Error importing data:', error);
          set({ 
            isLoading: false, 
            error: error instanceof Error ? error.message : 'Failed to import data' 
          });
          throw error;
        }
      }
    }),
    {
      name: 'mahfazhati-storage',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        sortOption: state.sortOption,
        filterOption: state.filterOption,
        autoBackupEnabled: state.autoBackupEnabled,
        autoBackupFrequency: state.autoBackupFrequency,
        lastBackupDate: state.lastBackupDate
      })
    }
  )
);
