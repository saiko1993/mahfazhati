import React, { useState } from "react";
import { useRoute } from "wouter";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { NotificationBanner } from "@/components/layout/notification-banner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { 
  ArrowLeft, 
  Edit, 
  Trash2, 
  Plus, 
  LineChart, 
  Download,
  Filter,
  RefreshCw
} from "lucide-react";
import { Link } from "wouter";
import { useWallets } from "@/hooks/use-wallets";
import { useTransactions } from "@/hooks/use-transactions";
import { Amount, LimitDisplay, Date as ArabicDate, TransactionAmount, TransactionType } from "@/components/ui/arabic-numbers";
import { 
  formatDateAr, 
  getWalletTypeColor, 
  getWalletTypeFirstLetter, 
  getWalletTypeName,
  downloadJSON
} from "@/lib/utils";
import { useStore } from "@/lib/zustand-store";
import { AddWalletModal } from "@/components/wallet/add-wallet-modal";
import { UpdateBalanceModal } from "@/components/wallet/update-balance-modal";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function WalletDetails() {
  const [, params] = useRoute<{ id: string }>("/wallet/:id");
  const walletId = params?.id || "";
  
  const { getWalletById } = useWallets();
  const wallet = getWalletById(walletId);
  
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isUpdateBalanceModalOpen, setIsUpdateBalanceModalOpen] = useState(false);
  const [isDeleteAlertOpen, setIsDeleteAlertOpen] = useState(false);
  const [transactionType, setTransactionType] = useState<string>("all");
  
  const { deleteWallet } = useStore();
  
  const { transactions, loading: loadingTransactions } = useTransactions({
    walletId,
    type: transactionType === "all" ? undefined : transactionType as any,
    pageSize: 20
  });
  
  const handleDeleteWallet = async () => {
    if (!wallet) return;
    
    try {
      await deleteWallet(wallet.id);
      window.location.href = "/";
    } catch (error) {
      console.error("Failed to delete wallet:", error);
    }
  };
  
  const handleExportTransactions = () => {
    if (!wallet || !transactions.length) return;
    
    const filename = `transactions-${wallet.name}-${new Date().toISOString().slice(0, 10)}.json`;
    downloadJSON(transactions, filename);
  };
  
  if (!wallet) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1 container mx-auto px-4 py-6">
          <Link href="/">
            <a className="flex items-center text-primary-600 mb-6">
              <ArrowLeft className="h-4 w-4 ml-1" />
              العودة للرئيسية
            </a>
          </Link>
          
          <div className="text-center py-12">
            <h1 className="text-2xl font-bold mb-4">المحفظة غير موجودة</h1>
            <p className="text-gray-600 mb-6">لم يتم العثور على المحفظة المطلوبة.</p>
            <Button asChild>
              <Link href="/">العودة للرئيسية</Link>
            </Button>
          </div>
        </main>
        
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <NotificationBanner />
      
      <main className="flex-1 container mx-auto px-4 py-6">
        <Link href="/">
          <a className="flex items-center text-primary-600 mb-6">
            <ArrowLeft className="h-4 w-4 ml-1" />
            العودة للرئيسية
          </a>
        </Link>
        
        {/* Wallet Header */}
        <div className="mb-8">
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-3">
              <div className={`${getWalletTypeColor(wallet.type)} h-10 w-10 rounded-full flex items-center justify-center text-lg`}>
                {getWalletTypeFirstLetter(wallet.type)}
              </div>
              <div>
                <h1 className="text-2xl font-bold">{wallet.name}</h1>
                <p className="text-gray-500">{wallet.phoneNumber} | {getWalletTypeName(wallet.type)}</p>
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="flex items-center gap-1 ml-2"
                onClick={() => setIsUpdateBalanceModalOpen(true)}
              >
                <RefreshCw className="h-4 w-4" />
                تحديث الرصيد
              </Button>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="secondary" size="sm" className="flex items-center gap-1">
                    المزيد
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => setIsEditModalOpen(true)}>
                    <Edit className="h-4 w-4 ml-2" />
                    تعديل المحفظة
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleExportTransactions}>
                    <Download className="h-4 w-4 ml-2" />
                    تصدير المعاملات
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    className="text-red-600"
                    onClick={() => setIsDeleteAlertOpen(true)}
                  >
                    <Trash2 className="h-4 w-4 ml-2" />
                    حذف المحفظة
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
        
        {/* Wallet Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="p-5">
            <h2 className="text-gray-600 text-sm mb-2">الرصيد</h2>
            <Amount value={wallet.balance} className="text-2xl font-bold" />
            <p className="text-xs text-gray-500 mt-1">
              آخر تحديث: <ArabicDate value={wallet.lastUpdated} />
            </p>
          </Card>
          
          <Card className="p-5">
            <h2 className="text-gray-600 text-sm mb-2">الحد الشهري</h2>
            <Amount value={wallet.monthlyLimit} className="text-2xl font-bold" />
          </Card>
          
          <Card className="p-5">
            <h2 className="text-gray-600 text-sm mb-2">الحد المتبقي</h2>
            <div className="mb-2">
              <Amount value={wallet.remainingLimit} className="text-2xl font-bold" />
            </div>
            <LimitDisplay
              remaining={wallet.remainingLimit}
              total={wallet.monthlyLimit}
              showText={false}
            />
          </Card>
        </div>
        
        {/* Transactions */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">سجل المعاملات</h2>
            <div className="flex items-center gap-2">
              <Select 
                value={transactionType} 
                onValueChange={setTransactionType}
              >
                <SelectTrigger className="h-9 w-40">
                  <Filter className="h-4 w-4 ml-2" />
                  <SelectValue placeholder="جميع المعاملات" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع المعاملات</SelectItem>
                  <SelectItem value="deposit">إيداعات</SelectItem>
                  <SelectItem value="withdrawal">سحوبات</SelectItem>
                  <SelectItem value="transfer">تحويلات</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Card className="overflow-hidden border border-gray-100">
            {loadingTransactions ? (
              <div className="p-8 text-center">
                جاري تحميل المعاملات...
              </div>
            ) : transactions.length === 0 ? (
              <div className="p-8 text-center">
                <LineChart className="h-12 w-12 mx-auto text-gray-300 mb-4" />
                <h3 className="text-lg font-medium mb-2">لا توجد معاملات</h3>
                <p className="text-gray-500 mb-4">لم تقم بإضافة أي معاملات لهذه المحفظة بعد.</p>
                <Button
                  onClick={() => setIsUpdateBalanceModalOpen(true)}
                  className="bg-primary-600 hover:bg-primary-700"
                >
                  <RefreshCw className="h-4 w-4 ml-2" />
                  تحديث الرصيد
                </Button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 text-right">
                    <tr>
                      <th className="py-3 px-4 text-sm font-medium text-gray-600 whitespace-nowrap">التاريخ</th>
                      <th className="py-3 px-4 text-sm font-medium text-gray-600 whitespace-nowrap">النوع</th>
                      <th className="py-3 px-4 text-sm font-medium text-gray-600 whitespace-nowrap">المبلغ</th>
                      <th className="py-3 px-4 text-sm font-medium text-gray-600 whitespace-nowrap">الوصف</th>
                      <th className="py-3 px-4 text-sm font-medium text-gray-600 whitespace-nowrap">الرقم المرجعي</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {transactions.map((transaction) => (
                      <tr key={transaction.id}>
                        <td className="py-3 px-4 text-sm text-gray-800 whitespace-nowrap">
                          <ArabicDate value={transaction.date || new Date().toISOString()} />
                        </td>
                        <td className="py-3 px-4 text-sm whitespace-nowrap">
                          <TransactionType type={transaction.type} />
                        </td>
                        <td className="py-3 px-4 text-sm font-medium whitespace-nowrap">
                          <TransactionAmount amount={transaction.amount} type={transaction.type} />
                        </td>
                        <td className="py-3 px-4 text-sm text-gray-600 whitespace-nowrap">
                          {transaction.description}
                        </td>
                        <td className="py-3 px-4 text-sm text-gray-500 whitespace-nowrap">
                          {transaction.reference || "-"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>
      </main>
      
      <Footer />
      
      {/* Modals */}
      <AddWalletModal 
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        walletToEdit={wallet}
      />
      
      <UpdateBalanceModal
        isOpen={isUpdateBalanceModalOpen}
        onClose={() => setIsUpdateBalanceModalOpen(false)}
        wallet={wallet}
      />
      
      <AlertDialog open={isDeleteAlertOpen} onOpenChange={setIsDeleteAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>هل أنت متأكد من حذف هذه المحفظة؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيتم حذف المحفظة وجميع معاملاتها بشكل نهائي. هذا الإجراء لا يمكن التراجع عنه.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={handleDeleteWallet}>
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
