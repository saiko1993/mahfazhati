import React, { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AIAssistant } from "@/components/ai/ai-assistant";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Heading } from "@/components/ui/heading";
import { Bot, BarChart3, LightbulbIcon, TrendingUp, Clock, Zap } from "lucide-react";
import { useWallets } from "@/hooks/use-wallets";
import { useTransactions } from "@/hooks/use-transactions";
import { 
  analyzeTransactionPatterns, 
  generateSmartRecommendations,
  predictLimitExhaustion,
  type AIRecommendation, 
  type TransactionPatternAnalysis,
  type LimitPrediction
} from "@/lib/ai-services";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { formatDateAr, formatCurrencyAr } from "@/lib/utils";

export default function AIInsightsPage() {
  const [activeTab, setActiveTab] = useState("assistant");
  const { wallets } = useWallets();
  const { transactions } = useTransactions();
  
  const [recommendations, setRecommendations] = useState<AIRecommendation[]>([]);
  const [transactionPatterns, setTransactionPatterns] = useState<TransactionPatternAnalysis | null>(null);
  const [limitPredictions, setLimitPredictions] = useState<Record<string, LimitPrediction>>({});
  
  const [isLoadingRecs, setIsLoadingRecs] = useState(false);
  const [isLoadingPatterns, setIsLoadingPatterns] = useState(false);
  const [isLoadingPredictions, setIsLoadingPredictions] = useState(false);
  
  // تحميل التوصيات الذكية
  const loadRecommendations = async () => {
    setIsLoadingRecs(true);
    try {
      const recs = await generateSmartRecommendations(wallets, transactions);
      setRecommendations(recs);
    } catch (error) {
      console.error('خطأ في تحميل التوصيات:', error);
    } finally {
      setIsLoadingRecs(false);
    }
  };
  
  // تحميل تحليل أنماط المعاملات
  const loadTransactionPatterns = async () => {
    setIsLoadingPatterns(true);
    try {
      const patterns = await analyzeTransactionPatterns(transactions);
      setTransactionPatterns(patterns);
    } catch (error) {
      console.error('خطأ في تحليل أنماط المعاملات:', error);
    } finally {
      setIsLoadingPatterns(false);
    }
  };
  
  // تحميل توقعات استنفاد الحد الشهري
  const loadLimitPredictions = async () => {
    setIsLoadingPredictions(true);
    try {
      const predictions: Record<string, LimitPrediction> = {};
      
      // تحميل التوقعات لكل محفظة
      for (const wallet of wallets) {
        const walletTransactions = transactions.filter(t => t.walletId === wallet.id);
        const prediction = await predictLimitExhaustion(wallet, walletTransactions);
        predictions[wallet.id] = prediction;
      }
      
      setLimitPredictions(predictions);
    } catch (error) {
      console.error('خطأ في تحميل توقعات استنفاد الحد:', error);
    } finally {
      setIsLoadingPredictions(false);
    }
  };
  
  // تعيين نوع Badge بناءً على نوع التوصية
  const getRecommendationBadge = (type: string) => {
    switch (type) {
      case 'usage':
        return <Badge variant="outline" className="bg-blue-50 text-blue-600 border-blue-200">استخدام</Badge>;
      case 'transfer':
        return <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">تحويل</Badge>;
      case 'alert':
        return <Badge variant="outline" className="bg-red-50 text-red-600 border-red-200">تنبيه</Badge>;
      case 'insight':
        return <Badge variant="outline" className="bg-purple-50 text-purple-600 border-purple-200">رؤية</Badge>;
      default:
        return <Badge variant="outline">معلومات</Badge>;
    }
  };
  
  return (
    <div className="container mx-auto p-4">
      <header className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <div className="bg-primary/10 p-2 rounded-full">
            <Zap className="h-6 w-6 text-primary" />
          </div>
          <Heading title="الرؤى الذكية" subtitle="استفد من تحليلات الذكاء الاصطناعي لتحسين إدارة محافظك" />
        </div>
      </header>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4 mb-6">
          <TabsTrigger value="assistant" className="flex items-center gap-1.5">
            <Bot className="h-4 w-4" />
            <span>المساعد الذكي</span>
          </TabsTrigger>
          <TabsTrigger value="recommendations" className="flex items-center gap-1.5">
            <LightbulbIcon className="h-4 w-4" />
            <span>التوصيات</span>
          </TabsTrigger>
          <TabsTrigger value="patterns" className="flex items-center gap-1.5">
            <BarChart3 className="h-4 w-4" />
            <span>أنماط المعاملات</span>
          </TabsTrigger>
          <TabsTrigger value="predictions" className="flex items-center gap-1.5">
            <TrendingUp className="h-4 w-4" />
            <span>التنبؤات</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="assistant" className="md:p-4">
          <div className="max-w-3xl mx-auto">
            <AIAssistant />
          </div>
        </TabsContent>
        
        <TabsContent value="recommendations">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold font-cairo">التوصيات الذكية</h2>
              <p className="text-sm text-muted-foreground">
                توصيات مخصصة بناءً على تحليل بيانات محافظك
              </p>
            </div>
            <Button 
              onClick={loadRecommendations} 
              disabled={isLoadingRecs || wallets.length === 0}
              className="gap-1.5"
            >
              {isLoadingRecs ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Zap className="h-4 w-4" />
              )}
              تحليل وتوصية
            </Button>
          </div>
          
          {recommendations.length === 0 && !isLoadingRecs ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <p className="text-muted-foreground">
                  اضغط على زر "تحليل وتوصية" للحصول على توصيات ذكية مخصصة لمحافظك ومعاملاتك.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              {recommendations.map((rec, index) => (
                <Card key={index}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-base">{rec.title}</CardTitle>
                        <CardDescription className="text-xs mt-1">
                          {new Date(rec.timestamp).toLocaleDateString('ar-EG')}
                        </CardDescription>
                      </div>
                      {getRecommendationBadge(rec.type)}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm">{rec.description}</p>
                    {rec.actionText && (
                      <Button 
                        className="mt-4 w-full"
                        variant={rec.actionType === 'positive' ? 'default' : 
                                 rec.actionType === 'negative' ? 'destructive' : 'outline'}
                      >
                        {rec.actionText}
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="patterns">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold font-cairo">تحليل أنماط المعاملات</h2>
              <p className="text-sm text-muted-foreground">
                فهم أعمق لسلوك الإنفاق والاستخدام
              </p>
            </div>
            <Button 
              onClick={loadTransactionPatterns} 
              disabled={isLoadingPatterns || transactions.length === 0}
              className="gap-1.5"
            >
              {isLoadingPatterns ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <BarChart3 className="h-4 w-4" />
              )}
              تحليل الأنماط
            </Button>
          </div>
          
          {!transactionPatterns && !isLoadingPatterns ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <p className="text-muted-foreground">
                  اضغط على زر "تحليل الأنماط" للحصول على تحليل مفصل لأنماط معاملاتك.
                </p>
              </CardContent>
            </Card>
          ) : transactionPatterns && (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">أيام النشاط</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {transactionPatterns.frequentDays.map((day, i) => (
                      <div key={i} className="text-sm">{day}</div>
                    ))}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">معدل المعاملات</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">متوسط حجم المعاملة:</span>
                      <span className="font-bold">
                        {formatCurrencyAr(transactionPatterns.averageTransactionSize)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">المعاملات الكبيرة:</span>
                      <span className="font-bold">{transactionPatterns.largeTransactions}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">تقسيم الفئات</CardTitle>
                </CardHeader>
                <CardContent>
                  {Object.entries(transactionPatterns.categoryBreakdown || {}).length > 0 ? (
                    <div className="space-y-2">
                      {Object.entries(transactionPatterns.categoryBreakdown || {}).map(([category, percentage], i) => (
                        <div key={i} className="flex items-center justify-between">
                          <span className="text-sm">{category}:</span>
                          <span className="font-bold">{percentage}%</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">لا توجد بيانات كافية للتحليل</p>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="predictions">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold font-cairo">توقعات استنفاد الحد الشهري</h2>
              <p className="text-sm text-muted-foreground">
                توقعات دقيقة لمتى ستصل كل محفظة إلى حدها الشهري
              </p>
            </div>
            <Button 
              onClick={loadLimitPredictions} 
              disabled={isLoadingPredictions || wallets.length === 0}
              className="gap-1.5"
            >
              {isLoadingPredictions ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Clock className="h-4 w-4" />
              )}
              تحليل الحدود
            </Button>
          </div>
          
          {Object.keys(limitPredictions).length === 0 && !isLoadingPredictions ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <p className="text-muted-foreground">
                  اضغط على زر "تحليل الحدود" للحصول على توقعات استنفاد الحد الشهري لكل محفظة.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              {wallets.map(wallet => {
                const prediction = limitPredictions[wallet.id];
                if (!prediction) return null;
                
                let statusColor = "bg-green-100 border-green-300 text-green-800";
                if (prediction.daysUntilExhaustion < 7) {
                  statusColor = "bg-red-100 border-red-300 text-red-800";
                } else if (prediction.daysUntilExhaustion < 14) {
                  statusColor = "bg-orange-100 border-orange-300 text-orange-800";
                }
                
                return (
                  <Card key={wallet.id}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-base">{wallet.name}</CardTitle>
                        <Badge variant="outline" className={statusColor}>
                          {prediction.daysUntilExhaustion === 1 
                            ? 'يوم واحد' 
                            : `${prediction.daysUntilExhaustion} أيام`}
                        </Badge>
                      </div>
                      <CardDescription className="text-xs mt-1">
                        الحد المتبقي: {formatCurrencyAr(wallet.remainingLimit)}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {prediction.exhaustionDate && (
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">تاريخ النفاد المتوقع:</span>
                          <span className="font-medium">
                            {formatDateAr(prediction.exhaustionDate)}
                          </span>
                        </div>
                      )}
                      
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">الاستخدام اليومي المتوقع:</span>
                        <span className="font-medium">
                          {formatCurrencyAr(prediction.expectedPatterns.dailyUsage)}
                        </span>
                      </div>
                      
                      <div className="text-sm mt-4">
                        <p className="font-medium mb-1">التوصية:</p>
                        <p className="text-muted-foreground">{prediction.recommendation}</p>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}