import React, { useState } from "react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { NotificationBanner } from "@/components/layout/notification-banner";
import { DashboardOverview } from "@/components/dashboard/overview";
import { WalletSection } from "@/components/dashboard/wallet-section";
import { CyclicWalletStrategy } from "@/components/dashboard/cyclic-wallet-strategy";
import { TransactionHistory } from "@/components/dashboard/transaction-history";
import { SmartAnalysis } from "@/components/dashboard/smart-analysis";
import { BackupRestore } from "@/components/dashboard/backup-restore";
import { AddWalletModal } from "@/components/wallet/add-wallet-modal";
import { useWallets } from "@/hooks/use-wallets";

export default function Dashboard() {
  const { wallets, loading } = useWallets();
  const [isAddWalletModalOpen, setIsAddWalletModalOpen] = useState(false);
  
  const handleAddWalletClick = () => {
    setIsAddWalletModalOpen(true);
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <NotificationBanner />
      
      <main className="flex-1 container mx-auto px-4 py-6">
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <p className="text-gray-500">جاري تحميل البيانات...</p>
          </div>
        ) : (
          <>
            <DashboardOverview onAddWalletClick={handleAddWalletClick} />
            <WalletSection onAddWalletClick={handleAddWalletClick} />
            <CyclicWalletStrategy wallets={wallets} />
            <TransactionHistory />
            <SmartAnalysis />
            <BackupRestore />
          </>
        )}
      </main>
      
      <Footer />
      
      <AddWalletModal 
        isOpen={isAddWalletModalOpen}
        onClose={() => setIsAddWalletModalOpen(false)}
      />
    </div>
  );
}
